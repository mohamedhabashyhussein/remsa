# FastTrack Step by Step Topic Worksheet (General Research Track)

Based on the FastTrack Finding a Research Topic course (Topic Accelerator). Takes 3-5 hours and can save months on a topic that was never publishable. For any research project that is NOT a systematic review: empirical studies, dissertations, theses, qualitative projects, standalone papers.

## The three phases

**Phase 1: Find the topic neighbourhood (Convergence Method).** Passion, feasibility, and a debate that is genuinely alive. Same convergence logic as the systematic review track: all three must be present. Common issues the method catches: no gap or value add, not feasible, not highly cited.

**Phase 2: Test and refine (two tests plus the question).**

- **Duplication Test.** Find the 1-3 conceptual nearest-neighbour papers so the gap is real. How is the idea different, and what new value does it add? "No one has done this in my country" is not a gap.
- **Impact Test.** Forecast whether the paper will get cited. Evidence to gather: Are the nearest-neighbour papers accumulating citations, or sitting near zero? Is the debate appearing in strong journals for the field? Is there policy relevance or practical implication? A topic can be original and feasible and still fail here: nobody is waiting for the answer.
- **Sharpen the question.** A precise, one-sentence research question. PICO elements (population, intervention or exposure, comparison, outcome) help structure it where they fit the project type. For dissertations, the full GAP to research question to thesis aim chain belongs to the North Star Method.

**Phase 3 (optional but wise): Buy-in.** Supervisor or stakeholder alignment before going too far. A validated topic the supervisor will not approve is not validated. The Grandmother Rule applies here too: if the topic cannot be explained in 2-3 plain sentences, the buy-in conversation will not go well.

## Where feasibility differs from the systematic review track

The systematic review track's Feasibility Test counts original studies, because a review needs a corpus to synthesise (around 5 or more from a quick search; 8-10 for the final PICO question). The general track's feasibility is about execution: access to data, participants or materials, the skills needed or quickly acquirable, and fit within the timeframe.

## Next step after the worksheet

Bring the worksheet to a live FastTrack workshop, even partially completed, and get real feedback before committing. Final validation is human.
