# FastTrack Step-by-Step Worksheet: Identifying a Winning Systematic Review Topic (v2.31)

Based on Week 1 of the FastTrack Systematic Review course. Total estimated time: 3-5 hours. The worksheet follows the Convergence Method (Feasibility x Passion x Debate) and the PICO framework, with two quick tests (Duplication Test and Feasibility Test) to confirm the topic is original, realistic and worth pursuing.

## Part 1 - Finding the topic area (the Convergence Method)

**Step 1: Define research interests (30-45 minutes).** List 3-5 broad areas of interest. Rank by passion: which topic could they talk about at a party without losing interest? Systematic reviews require sustained engagement over months. Goal: a topic that motivates long-term engagement.

**Step 2: Assess feasibility, broad check (30-45 minutes).** For each top-ranked topic: Does it align with systematic review methodology (multiple studies to synthesise)? Can it be completed in 6-12 months? Do they have, or can they quickly acquire, the needed skills (Zotero, PRISMA, meta-analysis)? Is there accessible literature (quick search in Google Scholar, PubMed, Web of Science)? Eliminate topics that are too broad, unrealistic, or lack enough published studies. Check for low-hanging fruit: no existing review, or only outdated ones, may signal a gap; highly cited but understudied areas are promising. Goal: a feasible topic with existing studies but a clear gap.

**Step 3: Identify the debate and gauge its impact (30-45 minutes).** Find at least 5 recent papers (within 3 years). Look for conflicting conclusions, calls for more research, emerging evidence. Assess impact: are these papers in high-impact journals, highly cited, policy-relevant? The student summarises the current debate in 100-200 words. Goal: the topic connects to a live, impactful research discussion.

## Part 2 - Testing the topic (two quick checks)

**Step 4: Duplication Test - find the nearest-neighbour papers (30 minutes).** Search Google Scholar for the 1-3 key systematic reviews, meta-analyses or literature reviews closest to the idea (the conceptual nearest neighbours). Skim titles and abstracts, then answer: How is my idea different? What new value or angle could my paper add? If the topic looks almost identical to an existing review, adjust it: different timeframe, region or subgroup. Goal: confirm the research offers something genuinely new.

**Step 5: Feasibility Test - enough to review (20 minutes).** A systematic review works like a funnel: broad start, narrow finish. Search Google Scholar with a few plain words describing the main idea (for example "social media mental health adolescents"). Focus on original research papers, not reviews or commentaries. Around 5 or more relevant studies suggests the topic is feasible; fewer means too narrow or too new, so broaden and repeat Step 4. Perfect keywords do not matter at this stage; this is a reality check, not the final database search. Goal: confirm enough existing research exists to support a review.

## Part 3 - Final validation

**Step 6: Final validation (30 minutes).** Discuss the topic with a mentor or colleague, and submit it to a FastTrack workshop. Refine question or scope based on feedback. Grandmother Rule: can the topic be explained clearly in 2-3 sentences to someone outside the field? Goal: validate before investing further time. This step is done by humans, not AI.

**Final step: write the systematic review research question (45-60 minutes).** Use PICO:
- Population: who is being studied?
- Intervention (or Exposure): what factor is examined?
- Comparison: what is the control or alternative?
- Outcome: what effect or result is measured?

Example: "In adults with type 2 diabetes (P), does intermittent fasting (I) compared to standard calorie restriction (C) improve glycaemic control (O)?"

Feasibility check on the question: broad enough that a quick Google Scholar search finds at least 8-10 relevant studies. Goal: a precise, researchable systematic review question.

## Troubleshooting: common mistakes and fixes

1. Too broad a topic: narrow by defining specific variables (population, intervention, outcome) using PICO.
2. Too narrow a topic: if fewer than 8-10 relevant studies exist, broaden the scope.
3. No clear research gap: compare with conceptual nearest-neighbour papers to articulate what is missing.
4. Lack of feasibility: ensure access to enough data and methods within the timeframe.
5. Ignoring low-hanging fruit: choose a topic with existing literature but a clear gap.
6. Unclear research question: refine with PICO and seek mentor feedback.

## Next steps after the worksheet

Finalise the research question, begin database searches and keyword optimisation (Week 2 of the course), and get feedback from a mentor or the FastTrack Inner Circle or Research Collective community.
