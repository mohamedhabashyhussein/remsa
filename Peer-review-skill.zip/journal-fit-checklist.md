# Journal Fit Checklist

Things authors commonly miss when submitting to a peer-reviewed journal. Use in:
- **Phase 1 (Journal profiling)** — when reading author guidelines, check which items the journal requires
- **Phase 3 (Desk check)** — flag missing supplements
- **Phase 7.4 (Required-but-missing items)** — populate the table in Section 7 of the report

For each item: what it is, when it's required, and what good looks like.

---

## Cover letter

**What it is:** A short letter to the editor accompanying submission.

**When required:** Almost always, even if guidelines don't explicitly demand one. *Nature*, *Cell*, *Lancet*, *NEJM* explicitly weigh it in editorial triage.

**What good looks like:**
- Names the journal and article type
- States the headline finding in one sentence
- Argues *why this paper, why this journal* — fit with scope, advance over prior work
- Notes: not under review elsewhere, all authors approve, ethical approvals obtained
- Suggests 3–5 reviewers (and non-preferred if applicable)
- Stays under one page

**Common mistakes:** Generic letter that could apply to any submission; failing to argue journal fit; over-claiming; missing entirely.

---

## Highlights / key points

**What it is:** 3–5 bullet points (typically ≤85 characters each) summarising the main findings.

**When required:** Standard for Elsevier journals (*Cell* family, *Lancet*, many specialty titles).

**What good looks like:**
- Each bullet stands alone, readable without context
- Front-loads the finding, not the method
- Active voice, present tense
- Avoids jargon

**Common mistakes:** Rephrasing the abstract; method-heavy bullets; vague gestures ("our findings have implications").

---

## Graphical abstract

**What it is:** A single visual summary of the paper.

**When required:** Many Elsevier journals; increasingly common across publishers. Check exact dimensions and file format.

**What good looks like:**
- Self-explanatory without the paper
- Shows the question/input and the answer/output
- Minimal text labels
- Conforms to journal size/format requirements
- Color-blind safe palette

**Common mistakes:** Reusing a figure from the paper; too much text; wrong file format.

---

## Significance statement / plain language summary

**What it is:** Short paragraph (~100–150 words) explaining why the paper matters, for a non-specialist.

**When required:** *PNAS* (Significance Statement); *PLOS* (Author Summary); *BMJ* ("What does this study add?"); NIHR-funded UK journals.

**What good looks like:**
- Written for an educated non-specialist
- Avoids field jargon
- States what was unknown, what was done, what was found, why it matters
- Doesn't repeat the abstract

---

## Trial registration

**When required:** All clinical trials per ICMJE. Required by virtually every medical journal.

**What to check:**
- Registration number and registry in manuscript
- Date of registration vs. date of first enrollment (must be prospective for ICMJE journals)
- Outcomes in manuscript match pre-registered outcomes

**Common mistakes:** Retrospective registration without acknowledgment; outcome switching; registration number missing.

---

## Reporting-standard checklist

**What it is:** The completed checklist (CONSORT, PRISMA, ARRIVE, etc.) submitted as a supplementary file with page references.

**When required:** Many journals (*BMJ*, *PLOS Medicine*, *Lancet*). Even where not required, including it signals rigor.

**What good looks like:**
- Every item addressed with specific page/line number
- "N/A" items justified
- Matches the version the journal specifies

**Common mistakes:** Skipping it when required; vague references like "see Methods"; using an outdated version.

---

## ICMJE conflict of interest disclosure

**When required:** Most medical journals. Each author must complete the ICMJE Disclosure Form individually.

**What to check:** Manuscript declares COIs; forms submitted for every author; manuscript text and forms consistent.

---

## Author contributions (CRediT)

**What it is:** Statement assigning each author to CRediT roles (Conceptualization, Methodology, Software, Validation, Formal analysis, Investigation, Resources, Data Curation, Writing — Original Draft, Writing — Review & Editing, Visualization, Supervision, Project administration, Funding acquisition).

**When required:** Elsevier, Wiley, Cell Press, PLOS, and many others. ICMJE authorship criteria apply alongside.

**What good looks like:**
- Every author appears
- Roles are specific, not "all authors contributed equally"

---

## Data availability statement

**When required:** Mandatory at most journals now.

**What good looks like:**
- Specific repository name and accession ID
- Or clear conditional statement with process for legitimate access
- Aligns with the journal's data sharing policy

**Common mistakes:** "Available on request" alone where a repository deposit is feasible; vague language.

---

## Code availability statement

**When required:** *Nature* family for any computational paper; increasingly required elsewhere for ML/computational work.

**What good looks like:**
- Public repository link (GitHub, Zenodo)
- Specific version/commit/DOI
- License specified
- README adequate for reuse

---

## AI use disclosure

**What it is:** Statement on whether and how generative AI was used in writing or analysis.

**When required:** Now standard across most major publishers (post-2023). *Nature*, *Science*, JAMA, BMJ, Elsevier, Wiley, Cell Press, Springer Nature, *Lancet* all have policies.

**What good looks like:**
- Specific tool named if used (e.g., "GPT-4 was used to refine wording in the Discussion")
- Authors confirm responsibility for all content
- AI not listed as author (uniformly prohibited)

**Common mistakes:** Silence (now a violation at many journals); generic disclosure not specifying use.

---

## Suggested reviewers / non-preferred reviewers

**When required:** Some journals request in cover letter or submission system.

**What good looks like:**
- 3–5 suggested reviewers — experts in the field, no recent collaborators (typically 3–5 year window), no current institutional ties
- Brief justification per suggestion (one line)
- 1–2 non-preferred reviewers if genuine bias concerns (use sparingly)

---

## ORCID

**When required:** Mandatory for corresponding author at many journals; increasingly for all authors. PLOS, Wiley, Elsevier, Cell Press all require/strongly encourage.

---

## Preregistration

**When required:** Required by some psychology journals; increasingly encouraged. Registered Reports format pre-reviews the plan.

**What to check:** If claimed, link/DOI present; deviations from pre-registered plan acknowledged.

---

## Funding transparency

**What it is:** Statement of funding sources and the role of funders.

**When required:** Universal.

**What good looks like:**
- Specific grant numbers
- Funder role explicitly stated (e.g., "The funders had no role in study design, data collection and analysis, decision to publish, or preparation of the manuscript.")
- Industry funding flagged with role disclosure

---

## Specific peculiarities by journal family

| Publisher / journal family | Look out for |
|---|---|
| *Nature* family | Reporting Summary supplement required; strict word/figure limits; Editorial Policy Checklist; statistical reporting (effect size + CI, exact p-values, replicates definition); life sciences MUST submit Reporting Summary |
| *Cell* family | Highlights mandatory; Star Methods structure; KEY RESOURCES TABLE expected |
| *Lancet* family | Research in Context box (Evidence before / Added value / Implications); structured abstract |
| *NEJM* | Structured abstract (Background, Methods, Results, Conclusions); strict word limits; mandatory disclosure forms |
| *JAMA* family | Structured abstract; Key Points box (Question, Findings, Meaning); strict reporting standards adherence |
| *BMJ* | Patient and public involvement statement required; "What this study adds" box; structured abstract |
| *PLOS* | Author summary required; strict data availability (must deposit); broad ethics statement |
| *PNAS* | Significance Statement (≤120 words) for all research articles |
| *Science* family | Very tight word limits; editor's summary key messages |
| Elsevier specialty journals | Highlights + Graphical Abstract usually expected; CRediT for authorship |
| Frontiers family | Specific section structure; Open Access; high attention to ethics statements |
| MDPI journals (incl. Nutrients) | Structured abstract ≤200 words; sex/gender reporting requirement; data availability statement; APC applies |

---

## How to use this in the report

In Section 7.4 of the .docx (Required-but-missing items):

1. Cross-reference items above against (a) what the journal's author guidelines require and (b) what the manuscript contains.
2. List every required-but-missing item with a one-line action.
3. Flag items that are present but weak (e.g., generic cover letter, "available on request" data statement) as Minor or Major depending on severity.
4. Don't pad — only flag items that genuinely apply to this journal.
